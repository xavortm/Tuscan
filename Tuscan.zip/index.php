<?php get_header(); ?>

<div class="content">

	<?php get_template_part('loop', 'index'); ?>
	
</div><!-- END CONTENT -->
<?php get_sidebar('primary'); ?>

<?php get_footer(); ?>