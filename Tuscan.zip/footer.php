		</div><!-- end wwrapper -->
        
        <footer id="footer" class="wrapper">

            <p>Created by XavorTM | Copyrght 2012 (c) All rights reserver. Distributed under the GPL License.</p>
            
        </footer>

        <!-- ========================= END SITE ========================= -->
        
    </body>
</html>