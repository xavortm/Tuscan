<?php /* Template Name: Full Width Layoult */ ?>


<?php get_header(); ?>

<div class="content fullwidth">

	<?php get_template_part('loop', 'single'); ?>
	
</div><!-- END CONTENT -->

<?php get_footer(); ?>